const AWS = require("aws-sdk");
const crypto = require("crypto-secure-random-digit");

const sns = new AWS.SNS();

module.exports.handler = async (event= {}, context) => {
    var mobileNumber = event.request.userAttributes.phone_number;
    oneTimeAuthCode = crypto.randomDigits(6).join('');
    // await sendSMS(mobileNumber, totp, event.userName)
    event.response.privateChallengeParameters = { "otp" : otp };
    
    await sendTestEmail(otp, event.userName, context)
    console.log(JSON.stringify(event))
    return event
}

async function sendSMS(mobileNumber, otp, userName){
    const params = {"Message" : userName + ", your one-time MFA code is: " + otp, "PhoneNumber": mobileNumber};
    await sns.publish(params).promise();
}

async function sendTestEmail(otp, userName, context){
    var params = {
      Message: userName + ", your one-time MFA code is: " + otp, 
      TopicArn: 'arn:aws:sns:eu-west-2:475593055014:lambda_auth_test'
    };

    await sns.publish(params).promise();
}
